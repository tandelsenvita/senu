<?php
include("header.php");
?>

<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">About Us</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
					
					<div class="about">
					
						
						
						<div class="row">
        <div class="col-lg-6">
          <div class="about-carousel wow fadeInLeft animated" data-wow-animation-name="none">
            <div id="myCarousel" class="carousel slide">
              <!-- Carousel items -->
			   <img src="img/abt1.jpg" alt="">
             
             
            </div>
          </div>
        </div>
        <div class="col-lg-6 about wow fadeInRight animated" data-wow-animation-name="none" style="visibility: visible; -webkit-animation-name: none;">
			<h2>ABOUT TRADE FAIR</h2>
          <p align="justify">
            Trade Fairs and exhibitions are global events, with a diverse range of
					industries organizing it.Every industry has its particular needs and demands which our
					dedicated service providers at event plus are more than capable to comprehend and execute
					accordingly. Our event managers for fairs and exhibitions providers
					a made to order tailored event according to the industrial need of the business.
          </p>
		  <p>Trade Fair Categories</p>
          <ul class="list-unstyled">
            <li>
              <i class="fa fa-angle-right pr-10">
              </i>
              Machinery Trade Fair
            </li>

            <li>
              <i class="fa fa-angle-right pr-10">
              </i>
              Auto Trade Fair
            </li>

            <li>
              <i class="fa fa-angle-right pr-10">
              </i>
              Food Trade Fair
            </li>

            <li>
              <i class="fa fa-angle-right pr-10">
              </i>
              General Trade Fair
            </li>

            

            

          </ul>
          <blockquote>
            <p>
              Award winning Trade Fair. We bring a personal and effective approach to every Tradefair we work on, which is why.
            </p>
            <small>
            Miss. Dhruvi Tandel | Miss Senvita Tandel
            </small>
          </blockquote>
        </div>
      </div>
						<br>
						
						
						 						
						 
						<br>
						
					  
						
					</div>
									
				</div>
	</section>
	
          



<?php
include("footer.php");
?>