<?php
include("header.php");
include("connection.php");


?>
<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">UPCOMINGS TRADE FAIR</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">		
        <!-- Service Blcoks -->
		
	  
		<div class="col-md-8">
        <div class="row service-v1 margin-bottom-40">
        <?php
		$tdate=date("Y-m-d");
		if(isset($_REQUEST['catid']))
		{
			$catid=$_REQUEST['catid'];
			$res=mysql_query("select * from trade_fair_master where status='0' and book_last_date>='$tdate' and category_id='$catid'");
		}else{
			$res=mysql_query("select * from trade_fair_master where status='0' and book_last_date>='$tdate'");
		}
		if(mysql_num_rows($res)>0)
		{
			while($r=mysql_fetch_array($res))
			{
		?>
			<div class="col-md-6 md-margin-bottom-40">
               <img class="img-responsive" src="<?php echo $r[11]; ?>" style="width:345px; height:248px;" alt="">   
                <h3><?php echo $r[2]; ?></h3>
                <p>Booking Last Date: <?php echo $r[10]; ?></p>        
				<p>Trade Fair Start Date: <?php echo $r[9]; ?></p>        
				<p>No of Days: <?php echo $r[8]; ?></p> 
				
						<a href="view_stall_detail.php?tfid=<?php echo $r[0]; ?>" class="btn btn-medium"><i class="icon-bolt"></i>VIEW STALL</a>
				
            </div>
           
        <?php
			}
		}else{
			echo "<h3>No Trade Fair Found</h3>";
		}
		?> 
        </div>
        <!-- End Service Blcoks -->
        </div>
		<div class="col-md-4">
			<h3>CATEGORY</h3>
			<h4>
		<?php
		$qur=mysql_query("select * from trade_fair_category where status='0'");
		if(mysql_num_rows($qur)>0)
		{
			echo "<ul>";
			while($q=mysql_fetch_array($qur))
			{
				echo "<li style='margin-bottom:20px;'><a href='trade_fair.php?catid=$q[0]'>$q[1]</a></li>";
			}
			echo "</ul>";
		}
		?>
		</h4>
		</div>
    </div>
    </section>
<?php
include("footer.php");
?>