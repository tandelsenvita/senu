<?php
include("admin_header.php");
include("connection.php");

$qur=mysql_query("select max(category_id) from trade_fair_category");
$cid=0;
while($q=mysql_fetch_array($qur))
{
	$cid=$q[0];
}
$cid++;
?>
<script type="text/javascript">
function validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtcat.value=="")
	{
		alert("Please Enter Category");
		form1.txtcat.focus();
		return false;
	}else{
		if(!v.test(form1.txtcat.value))
		{
			alert("Please Enter Only Alphabets in Category");
			form1.txtcat.focus();
			return false;
		}
	}
}
</script>
<?php
if(isset($_POST['btnsave']))
{
	$cid=$_POST['txtcatid'];
	$cat=$_POST['txtcat'];
	$query="insert into trade_fair_category values('$cid','$cat','0')";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Saved Successfully');";
		echo "window.location.href='admin_manage_category.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['ucid']))
{
	$cid=$_REQUEST['ucid'];
	$qur2=mysql_query("select * from trade_fair_category where category_id='$cid'");
	$q2=mysql_fetch_array($qur2);
	$cat1=$q2[1];
}

if(isset($_POST['btnupdate']))
{
	$cid=$_POST['txtcatid'];
	$cat=$_POST['txtcat'];
	$query="update trade_fair_category set category='$cat' where category_id='$cid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Updated Successfully');";
		echo "window.location.href='admin_manage_category.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['dcid']))
{
	$cid=$_REQUEST['dcid'];
	$query="update trade_fair_category set status='1' where category_id='$cid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Not Visible Successfully');";
		echo "window.location.href='admin_manage_category.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['vcid']))
{
	$cid=$_REQUEST['vcid'];
	$query="update trade_fair_category set status='0' where category_id='$cid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Visible Successfully');";
		echo "window.location.href='admin_manage_category.php';";
		echo "</script>";
	}
}
?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>MANAGE CATEGORY</center></h2>
			</div>
								<div class="col-md-5">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post"  id="contactform" name="form1" class="contact">
											
											<div class="form-group has-feedback">
												<label for="email">Enter Category Id</label>
												<input type="text" class="form-control" name="txtcatid" placeholder="" value="<?php echo $cid; ?>" readonly>
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter Category*</label>
												<input type="text" class="form-control" name="txtcat" placeholder="" value="<?php echo $cat1; ?>">
												
											</div>
											
										<?php
										if(isset($_REQUEST['ucid']))
										{
											?>
											<input type="submit" value="UPDATE" name="btnupdate" class="submit btn btn-default" onclick="return validation();">
											<?php

										}else{
										?>
											<input type="submit" value="SAVE" name="btnsave" class="submit btn btn-default" onclick="return validation();">
											&nbsp;&nbsp;&nbsp;
										<?php
										}
										?>	
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-7">
								<?php
								$qur1=mysql_query("select * from trade_fair_category");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>CATEGORY ID</th>
												<th>CATEGORY</th>
												<th>CATEGORY STATUS</th>
												<th>UPDATE</th>
												<th>VISIBLE/NOT VISIBLE</th>
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											if($q1[2]=="0")
											{
												echo "<td>VISIBLE</td>";
												echo "<td><a href='admin_manage_category.php?ucid=$q1[0]'>UPDATE</a></td>";
											echo "<td><a href='admin_manage_category.php?dcid=$q1[0]'>DELETE</a></td>";
											}else{
												echo "<td>NOT VISIBLE</td>";
												echo "<td><a href='admin_manage_category.php?ucid=$q1[0]'>UPDATE</a></td>";
											echo "<td><a href='admin_manage_category.php?vcid=$q1[0]'>VISIBLE</a></td>";
											}
											
											
											echo "</tr>";
										}
									echo "</table>";
								}else{
									echo "<h2>NO TRADE FAIR CATEGORY FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>