<?php
session_start();
include("header.php");
include("connection.php");

$bid=$_REQUEST['bid'];
$res5=mysql_query("select * from booking_detail where booking_id='$bid'");
$r5=mysql_fetch_array($res5);
$stid=$r5[3];
$res6=mysql_query("select * from stall_detail where stall_id='$stid'");
$r6=mysql_fetch_array($res6);
$amt=$r6[4];

?>
<script type="text/javascript">
function validation()
{
	if(form1.selcardtype.value=="0")
	{
		alert("Please Select Card Type");
		form1.selcardtype.focus();
		return false;
	}
	
	var v=/^[a-zA-Z ]+$/
	if(form1.txtbname.value=="")
	{
		alert("Please Enter Bank Name");
		form1.txtbname.focus();
		return false;
	}else{
		if(!v.test(form1.txtbname.value))
		{
			alert("Please Enter Only Alphabets in Bank Name");
			form1.txtbname.focus();
			return false;
		}
	}
	
	if(form1.txtcname.value=="")
	{
		alert("Please Enter Card Holder Name");
		form1.txtcname.focus();
		return false;
	}else{
		if(!v.test(form1.txtcname.value))
		{
			alert("Please Enter Only Alphabets in Card Holder Name");
			form1.txtcname.focus();
			return false;
		}
	}
	
	var v=/^[0-9]+$/;
	if(form1.txtcno.value=="")
	{
		alert("Please Enter 16 Digit Card No");
		form1.txtcno.focus();
		return false;
	}else if(form1.txtcno.value.length!=16){
		alert("Please Enter Your Card No 16 Digit Long");
		form1.txtcno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtcno.value))
		{
			alert("Please Enter Only Digits in Your Card No");
			form1.txtcno.focus();
			return false;
		}
	}
	
	if(form1.txtcvvno.value=="")
	{
		alert("Please Enter 3 Digit CVV No");
		form1.txtcvvno.focus();
		return false;
	}else if(form1.txtcvvno.value.length!=3){
		alert("Please Enter Your CVV No 3 Digit Long");
		form1.txtcvvno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtcvvno.value))
		{
			alert("Please Enter Only Digits in Your CVV No");
			form1.txtcvvno.focus();
			return false;
		}
	}
	
	
	
	
	

}
</script>

<?php
if(isset($_POST['btnpay']))
{
	$ctype=$_POST['selcardtype'];
	$bname=$_POST['txtbname'];
	$cname=$_POST['txtcname'];
	$cno=$_POST['txtcno'];
	$cvvno=$_POST['txtcvvno'];
	$expirydate=$_POST['selexmonth']."-".$_POST['selexyear'];
	
	

		$qur=mysql_query("select max(payment_id) from payment");
		$pid=0;
		while($q=mysql_fetch_array($qur))
		{
			$pid=$q[0];
		}
		$pid++;
		$query="insert into payment values('$pid','$bid','$ctype','$bname','$cname','$cno','$cvvno','$expirydate','$amt')";
		if(mysql_query($query))
		{
			echo "<script type='text/javascript'>";
			echo "alert('Payment Done');";
			echo "window.location.href='trade_fair.php';";
			echo "</script>";
		}
	
}
?>
<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">PAYMENT</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post" name="form1" id="contactform" class="contact">
											<div class="form-group has-feedback">
												<label for="email">Select Card Type*</label>
												<select class="form-control" name="selcardtype" >
													<option value="0">--Select Card Type--</option>
													<option value="Debit Card">Debit Card</option>
													<option value="Credit Card">Credit Card</option>
												</select>
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Bank Name</label>
												<input type="text" class="form-control" name="txtbname" placeholder="">
												
											</div>
											
											<div class="form-group has-feedback">
												<label for="email">Enter Card Holder Name</label>
												<input type="text" class="form-control" name="txtcname" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Card No*</label>
												<input type="text" class="form-control" name="txtcno" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter CVV No*</label>
												<input type="text" class="form-control" name="txtcvvno" placeholder="">
												
											</div>
											
											<div class="form-group has-feedback ">
												<div class="col-md-6">
												<label for="name">Select Expiry Month</label>
												 <select name="selexmonth" class="form-control">
													<option value="Jan">JAN</option>
													<option value="Feb">FEB</option>
													<option value="Mar">MAR</option>
													<option value="April">April</option>
													<option value="May">MAY</option>
													<option value="June">JUNE</option>
													<option value="July">JULY</option>
													<option value="Aug">AUG</option>
													<option value="Sep">SEP</option>
													<option value="Oct">OCT</option>
													<option value="Nov">NOV</option>
													<option value="Dec">DEC</option>
													</select>
												</div>
											</div>
											
											<div class="form-group has-feedback col-md-6">
												<label for="name">Select Expiry Year*</label>
													<select name="selexyear" class="form-control">
					<option value="2021">2021</option>
					<option value="2022">2022</option>
					<option value="2023">2023</option>
					<option value="2024">2024</option>
					<option value="2025">2025</option>
					<option value="2026">2026</option>
					<option value="2027">2027</option>
					<option value="2028">2028</option>
					<option value="2029">2029</option>
					<option value="2030">2030</option>
				</select>
												
											</div>
											
											
											<input type="submit" value="PAY Rs.<?php echo $amt; ?> /-" onclick="return validation();" name="btnpay" class="submit btn btn-default">
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-6">
									<br/><br/><br/>
 <img src="img/regis.png" style="width:700px; height:600px;"alt="">


								</div>
							</div>
							
	</div>
 
	</section>

<?php
include("footer.php");
?>