<?php
include("admin_header.php");
include("connection.php");

$qur=mysql_query("select max(fair_id) from trade_fair_master");
$fid=0;
while($q=mysql_fetch_array($qur))
{
	$fid=$q[0];
}
$fid++;
?>
<script type="text/javascript">
function validation()
{
	if(form1.selcat.value=="0")
	{
		alert("Please Select Category");
		form1.selcat.focus();
		return false;
	}
	
	var v=/^[a-zA-Z0-9 ]+$/
	if(form1.txtname.value=="")
	{
		alert("Please Enter Trade Fair Name");
		form1.txtname.focus();
		return false;
	}else{
		if(!v.test(form1.txtname.value))
		{
			alert("Please Enter Only Alphabets and Digits in Trade Fair Name");
			form1.txtname.focus();
			return false;
		}
	}
	
	if(form1.txtdesc.value=="")
	{
		alert("Please Enter Trade Fair Description");
		form1.txtdesc.focus();
		return false;
	}
	
	if(form1.txtadd.value=="")
	{
		alert("Please Enter Trade Fair Address");
		form1.txtadd.focus();
		return false;
	}
	
	var v=/^[a-zA-Z ]+$/
	if(form1.txtcity.value=="")
	{
		alert("Please Enter Trade Fair City Name");
		form1.txtcity.focus();
		return false;
	}else{
		if(!v.test(form1.txtcity.value))
		{
			alert("Please Enter Only Alphabets in Trade Fair City Name");
			form1.txtcity.focus();
			return false;
		}
	}
	
	var v=/^[0-9]+$/
	if(form1.txtmno.value=="")
	{
		alert("Please Enter Trade Fair Mobile No");
		form1.txtmno.focus();
		return false;
	}else if(form1.txtmno.value.length!=10)
	{
		alert("Please Enter Only 10 Digits in Trade Fair Mobile No");
		form1.txtmno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtmno.value))
		{
			alert("Please Enter Only Digits in Trade Fair Mobile No");
			form1.txtmno.focus();
			return false;
		}
	}
	
	
	if(form1.txtnstall.value=="")
	{
		alert("Please Enter No of Stall");
		form1.txtnstall.focus();
		return false;
	}else if((parseInt(form1.txtnstall.value))<=0)
	{
		alert("Please Enter No of Stall Greater than 0");
		form1.txtnstall.focus();
		return false;
	}else if((parseInt(form1.txtnstall.value))>100)
	{
		alert("Please Enter No of Stall Less than Equal to 100");
		form1.txtnstall.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtnstall.value))
		{
			alert("Please Enter Only Digits in No of stall");
			form1.txtnstall.focus();
			return false;
		}
	}
	
	if(form1.txtndays.value=="")
	{
		alert("Please Enter No of Days");
		form1.txtndays.focus();
		return false;
	}else if((parseInt(form1.txtndays.value))<=0)
	{
		alert("Please Enter No of Days Greater than 0");
		form1.txtndays.focus();
		return false;
	}else if((parseInt(form1.txtndays.value))>=5)
	{
		alert("Please Enter No of Days Less than Equal to 5");
		form1.txtndays.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtndays.value))
		{
			alert("Please Enter Only Digits in No of Days");
			form1.txtndays.focus();
			return false;
		}
	}
	
	var fname=document.getElementById('txtimg').value;
		var ext=fname.substr(fname.lastIndexOf(".")+1).toLowerCase().trim();
		if(document.getElementById('txtimg').value=="")
		{
			alert("Please Select Trade Fair Image");
			return false;
		}else{
			if(!(ext=="jpg" || ext=="png" || ext=="jpeg"))
			{
				alert("Please Select  Trade Fair Image in Format like jpg jpeg or png");
				return false;
			}
			
		}
}
</script>
<?php
if(isset($_POST['btnsave']))
{
	$fid=$_POST['txtfid'];
	$catid=$_POST['selcat'];
	$name=$_POST['txtname'];
	$desc=$_POST['txtdesc'];
	$add=$_POST['txtadd'];
	$city=$_POST['txtcity'];
	$mno=$_POST['txtmno'];
	$nstall=$_POST['txtnstall'];
	$ndays=$_POST['txtndays'];
	$fsdate=date("Y-m-d",strtotime($_POST['txtsdate']));
	$bldate=date("Y-m-d",strtotime("$_POST[txtsdate] -1 days"));
	$tpath=$_FILES['txtimg']['tmp_name'];
	$ipath="fair_image/F".$fid."_".rand(1000,9999).".png";
	$query="insert into trade_fair_master values('$fid','$catid','$name','$desc','$add','$city','$mno','$nstall','$ndays','$fsdate','$bldate','$ipath','0')";
	if(mysql_query($query))
	{
		move_uploaded_file($tpath,$ipath);
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Saved Successfully ');";
		echo "window.location.href='admin_manage_stall.php?tfid=$fid&nstall=$nstall';";
		echo "</script>";
	}
}



if(isset($_REQUEST['dfid']))
{
	$fid=$_REQUEST['dfid'];
	$query="update trade_fair_master set status='1' where fair_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Not Visible Successfully');";
		echo "window.location.href='admin_manage_trade_fair.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['vfid']))
{
	$fid=$_REQUEST['vfid'];
	$query="update trade_fair_master set status='0' where fair_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Visible Successfully');";
		echo "window.location.href='admin_manage_trade_fair.php';";
		echo "</script>";
	}
}
?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>MANAGE TRADE FAIR</center></h2>
			</div>
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post"  id="contactform" name="form1" class="contact" enctype="multipart/form-data">
											
											<div class="form-group has-feedback">
												<label for="email">Enter Trade Fair Id</label>
												<input type="text" class="form-control" name="txtfid" placeholder="" value="<?php echo $fid; ?>" readonly>
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Select Category</label>
												<select class="form-control" name="selcat" >
													<option value="0">--Select Category--</option>
												<?php
												$qur9=mysql_query("select * from trade_fair_category where status='0'");
												while($q9=mysql_fetch_array($qur9))
												{
													?>
													<option value="<?php echo $q9[0]; ?>"><?php echo $q9[1]; ?></option>
													<?php
												}
												?>
												</select>
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter Trade Fair Name</label>
												<input type="text" class="form-control" name="txtname" placeholder="" value="<?php echo $name1; ?>">
												
											</div>
											<div class="form-group has-feedback">
												<label for="message">Enter Trade Fair Description*</label>
												<textarea class="form-control" rows="3" name="txtdesc" placeholder=""></textarea>
												
											</div>
											<div class="form-group has-feedback">
												<label for="message">Enter Address*</label>
												<textarea class="form-control" rows="3" name="txtadd" placeholder=""></textarea>
												
											</div>
											
										
										 
										
									</div>
								</div>
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											<div class="form-group has-feedback">
												<label for="email">Enter City*</label>
												<input type="text" class="form-control" name="txtcity" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Mobile No*</label>
												<input type="text" class="form-control" name="txtmno" placeholder="" value="<?php echo $mno1; ?>">
												
											</div>
											
											<div class="form-group has-feedback">
												<label for="name">Enter No Of Stall</label>
												<input type="text" class="form-control" name="txtnstall" placeholder="" value="<?php echo $nstall1; ?>">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter No Of Days</label>
												<input type="text" class="form-control" name="txtndays" placeholder="" value="<?php echo $ndays1; ?>">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter Fair Start Date</label>
												<input type="date" class="form-control" name="txtsdate" value="<?php echo date("Y-m-d",strtotime("+10 days")); ?>" min="<?php echo date("Y-m-d",strtotime("+10 days")); ?>">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Select Trade Fair Image</label>
												<input type="file" class="form-control" name="txtimg" id="txtimg" >
												
											</div>
										<?php
										if(isset($_REQUEST['ucid']))
										{
											?>
											<input type="submit" value="UPDATE" name="btnupdate" class="submit btn btn-default" onclick="return validation();">
											<?php

										}else{
										?>
											<input type="submit" value="SAVE" name="btnsave" class="submit btn btn-default" onclick="return validation();">
											&nbsp;&nbsp;&nbsp;
										<?php
										}
										?>	
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-12">
								<?php
								$qur1=mysql_query("select * from trade_fair_master");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>FAIR ID</th>
												<th>CATEGORY</th>
												<th>FAIR NAME</th>
												<th>DESCRIPTION</th>
												<th>ADDRESS</th>
												<th>MOBILE NO</th>
												<th>NO OF STALL</th>
												<th>NO OF DAYS</th>
												<th>FAIR START DATE</th>
												<th>BOOKING LAST DATE</th>
												<th>FAIR IMAGE</th>
												<th>EDIT STALL</th>
												<th>FAIR STATUS</th>
												
												<th>VISIBLE/NOT VISIBLE</th>
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											echo "<td>$q1[2]</td>";
											echo "<td>$q1[3]</td>";
											echo "<td>$q1[4] $q1[5]</td>";
											echo "<td>$q1[6]</td>";
											echo "<td>$q1[7]</td>";
											echo "<td>$q1[8]</td>";
											echo "<td>".date("d-m-Y",strtotime($q1[9]))."</td>";
											echo "<td>".date("d-m-Y",strtotime($q1[10]))."</td>";
											echo "<td><a href='$q1[11]' target='_blank'><img src='$q1[11]' style='width:250px; height:50px;'></a></td>";
											echo "<td><a href='admin_update_stall.php?tfid=$q1[0]&nstall=$q1[7]'>VIEW STALL</a></td>";
											if($q1[12]=="0")
											{
												echo "<td>VISIBLE</td>";
												
											echo "<td><a href='admin_manage_trade_fair.php?dfid=$q1[0]'>DELETE</a></td>";
											}else{
												echo "<td>NOT VISIBLE</td>";
												
											echo "<td><a href='admin_manage_trade_fair.php?vfid=$q1[0]'>VISIBLE</a></td>";
											}
											
											
											echo "</tr>";
										}
									echo "</table>";
								}else{
									echo "<h2>NO TRADE FAIR CATEGORY FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>