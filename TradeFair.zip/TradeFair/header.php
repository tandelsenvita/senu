<?php
session_start();
?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">

    <title>Trade Fair</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="description">
    <meta content="http://webthemez.com" name="author">
	<!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
    <link href="css/jcarousel.css" rel="stylesheet">
    <link href="css/flexslider.css" rel="stylesheet">
    <link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<body>
    <div class="home-page" id="wrapper">
        <!-- start header -->

        <header>
            <div class="navbar navbar-default navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=
                        ".navbar-collapse" data-toggle="collapse" type=
                        "button"><span class="icon-bar"></span> <span class=
                        "icon-bar"></span> <span class=
                        "icon-bar"></span></button> <a class="navbar-brand"
                        href="index.html"><img alt="logo" src=
                        "img/logo2.png"></a>
                    </div>

                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="index.php">Home</a>
                            </li>

                            <li>
                                <a href="about.php">About Us</a>
                            </li>

                            <li>
                                <a href="trade_fair.php">Trade Fair</a>
                            </li>
						<?php
						if(isset($_SESSION['userid']))
						{
							?>
							<li>
                                <a href="view_stall_booking_detail.php">View Stall Booking</a>
                            </li>
							<?php
						}else{
						?>
                            <li>
                                <a href="login.php">Login</a>
                            </li>
						<?php
						}
						?>
                            

                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
						<?php
						if(isset($_SESSION['userid']))
						{
							?>
							<li>
                                <a href="logout.php">Logout</a>
                            </li>
							<?php
						}
						?>
                        </ul>
                    </div>
                </div>
            </div>
        </header><!-- end header -->
