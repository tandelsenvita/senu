<?php
session_start();
include("header.php");
include("connection.php");

if(isset($_POST['btnregister']))
{
	header("Location: register.php");
}

if(isset($_POST['btnlogin']))
{
	$email=$_POST['txtemail'];
	$pwd=$_POST['txtpwd'];
	$res=mysql_query("select * from admin_login where email_id='$email' and password='$pwd'");
	if(mysql_num_rows($res)>0)
	{
		echo "<script type='text/javascript'>";
		echo "alert('Admin Login Successfully');";
		echo "window.location.href='admin_manage_category.php';";
		echo "</script>";
	}else{
		$res2=mysql_query("select * from user_registration where email_id='$email' and password='$pwd'");
		if(mysql_num_rows($res2)>0)
		{
			$r2=mysql_fetch_array($res2);
			$_SESSION['userid']=$r2[0];
			if(isset($_SESSION['stid']))
			{
				$stid=$_SESSION['stid'];
				$tfid=$_SESSION['tfid'];
				$bdate=date("Y-m-d");
				$userid=$r2[0];
				
				$qur=mysql_query("select max(booking_id) from booking_detail");
				$bid=0;
				while($q=mysql_fetch_array($qur))
				{
					$bid=$q[0];
				}
				$bid++;
				$query="insert into booking_detail values('$bid','$bdate','$userid','$stid','$tfid')";
				if(mysql_query($query))
				{
					unset($_SESSION['tfid']);
					unset($_SESSION['stid']);
					echo "<script type='text/javascript'>";
					echo "alert('User Login & Stall Booked Successfully');";
					echo "window.location.href='user_payment.php?bid=$bid';";
					echo "</script>";
				}
			}else{
				echo "<script type='text/javascript'>";
				echo "alert('User Login Successfully');";
				echo "window.location.href='trade_fair.php';";
				echo "</script>";
			}
			
		}else{
			echo "<script type='text/javascript'>";
			echo "alert('Check Your Email ID or Password');";
			echo "window.location.href='login.php';";
			echo "</script>";
		}
	}
}
?>
<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">LOGIN</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post"  id="contactform" class="contact">
											
											<div class="form-group has-feedback">
												<label for="email">Enter Email*</label>
												<input type="email" class="form-control" name="txtemail" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter Password*</label>
												<input type="password" class="form-control" name="txtpwd" placeholder="">
												
											</div>
											
											<input type="submit" value="LOGIN" name="btnlogin" class="submit btn btn-default">
											&nbsp;&nbsp;&nbsp;
											<input type="submit" value="CREATE NEW ACCOUNT" name="btnregister" class="submit btn btn-default">
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-6">
								
 <img src="img/log1.png" alt="">


								</div>
							</div>
							
	</div>
 
	</section>

<?php
include("footer.php");
?>