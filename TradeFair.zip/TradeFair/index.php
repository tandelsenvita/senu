<?php
include("header.php");
?>
<section id="banner">
            <!-- Slider -->

            <div class="flexslider" id="main-slider">
                <ul class="slides">
                    <li>
                        <img alt="" src="img/banner1.jpg">

                        <div class="flex-caption wow fadeInLeft animated" data-wow-animation-name="none">
                            <h3>Trade Fair</h3>

                            <p>Stall Booking Facility</p>
                        </div>
                    </li>
					<li>
                        <img alt="" src="img/banner2.jpg">

                        <div class="flex-caption wow fadeInRight animated" data-wow-animation-name="none">
                            <h3></h3>

                            <p></p>
                        </div>
                    </li>
                    <li>
                        <img alt="" src="img/banner3.jpg">

                        <div class="flex-caption wow fadeInRight animated" data-wow-animation-name="none">
                            <h3></h3>

                            <p></p>
                        </div>
                    </li>
					 <li>
                        <img alt="" src="img/banner4.png">

                        <div class="flex-caption wow fadeInRight animated" data-wow-animation-name="none">
                            <h3></h3>

                            <p></p>
                        </div>
                    </li>
                </ul>
            </div><!-- end slider -->
        </section>

        <section class="hero-text">
            <div class="container">
                <div class="row"> 

                    <div class="col-lg-6 wow fadeInRight animated"
                    data-wow-animation-name="none">
                        <h2>Why Do We Need a Trade Fair?</h2> 
                        <p align="justify">
						Trade Fairs and exhibitions are global events, with a diverse range of
					industries organizing it.Every industry has its particular needs and demands which our
					dedicated service providers at event plus are more than capable to comprehend and execute
					accordingly. Our event managers for fairs and exhibitions providers
					a made to order tailored event according to the industrial need of the business.
						</p><br/> 
						
						
							
                        
                    </div>
					<div class="col-lg-6 wow fadeInRight animated"
                    data-wow-animation-name="none">
                        <h2>Our Mission</h2> 
						<p align="justify">
			Our Mission is to manage a big trade fair event at international Platform and successful that trade fair event through our big and hard working team.
			We thoroughly understand our client's needs and expectations, develop productive, cost effective programs, and successfully communicate with vendors to ensure each achieves its goals.</p><br/> 
							
                       <br/> 
							
                        
                    </div>
                </div>
            </div>
        </section>

		
        <section class="our-services">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="aligncenter">
                            <h2 class="aligncenter">Welcome to TradeFair.com</h2>
							<span>The International Leading Specialize Trade Event Oragnizer</span>
                        </div> 
                    </div>
                </div>

                <div class="row">
                    <div class="skill-home">
                        <div class="skill-home-solid clearfix">
                            <div class="col-md-4 text-center"> 
                                

                                <div class="box-area">
								<span class="icons c1 fa fa-upload" style=
                                "font-style: italic"></span>
                                    <h3> Upload Trade Fair</h3>

                                    <p>Admin Can Upload Trade Fair Detail with stall detail which is display to client for booking.</p>
                                </div> 
                            </div>

                            <div class="col-md-4 text-center">
                               

                                <div class="box-area">
								 <span class="icons c2 fa fa-search" style=
                                "font-style: italic"></span>
                                    <h3>Search Fair</h3>

                                    <p>Client can search and view the detail of trade fair with stall booking facility.</p>
                                </div>
                            </div>

                            <div class="col-md-4 text-center">
                               

                                <div class="box-area">
								 <span class="icons fa fa-file" style=
                                "font-style: italic"></span>
                                    <h3>Book Stall</h3>

                                    <p>After Searching a Stall detail client can book stall with online payment option.</p>
                                </div>
                            </div>

                            <!--div class="col-md-3 text-center">
                                

                                <div class="box-area">
								<span class="icons c4 fa fa-globe" style=
                                "font-style: italic"></span>
                                    <h3>User Experience</h3>

                                    <p>Lorem ipsum dolor sitamet, consec tetur
                                    adipisicing elit. Dolores quae porro
                                    consequatur aliquam, incidunt eius magni
                                    provident</p>
                                </div>
                            </div-->
                        </div>
                    </div>
                </div>
            </div>
        </section>

      
		   


<?php
include("footer.php");
?>