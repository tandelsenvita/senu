<?php
include("admin_header.php");
include("connection.php");

$tfid=$_REQUEST['tfid'];
$nstall=$_REQUEST['nstall'];


if(isset($_POST['btnupdate']))
{
	
	for($j=1;$j<=$nstall;$j++)
	{
		$sno=$_POST['txtstallno'.$j];
		$size=$_POST['txtsize'.$j];
		$charge=$_POST['txtcharge'.$j];
		
		$query="update stall_detail set stall_size='$size',stall_charge='$charge' where fair_id='$tfid' and stall_no='$sno'";
		mysql_query($query);
		
	}
	echo "<script type='text/javascript'>";
	echo "alert('Stall Detail Saved Successfully ');";
	echo "window.location.href='admin_manage_trade_fair.php';";
	echo "</script>";
	
}




?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>MANAGE STALL DETAIL</center></h2>
			</div>
			<form method="post"  id="contactform" name="form1" class="" enctype="multipart/form-data">
			<?php
			for($i=1;$i<=$nstall;$i++)
			{
				$qur=mysql_query("select * from stall_detail where stall_no='$i' and fair_id='$tfid'");
				$q=mysql_fetch_array($qur);
			?>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											
											<div class="form-group has-feedback">
												<label for="email">Enter Stall No</label>
												<input type="text" class="form-control" name="txtstallno<?php echo $i; ?>" placeholder="" value="<?php echo $q[2]; ?>" readonly>
												
											</div>
											
									</div>
								</div>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											<div class="form-group has-feedback">
												<label for="email">Enter Stall Size</label>
												<input type="text" class="form-control" name="txtsize<?php echo $i; ?>" placeholder="" value="<?php echo $q[3]; ?>" required>
												
											</div>
											
											
											
											
											
									
										 
										
									</div>
								</div>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											<div class="form-group has-feedback">
												<label for="email">Enter Stall Charge</label>
												<input type="number" class="form-control" name="txtcharge<?php echo $i; ?>" placeholder="" value="<?php echo $q[4]; ?>"required>
												
											</div>
											
											
											
											
											
										
										
										 
										
									</div>
								</div>
				<?php
				}
				?>
				
								<div class="col-md-12">
								
											<input type="submit" value="UPDATE" name="btnupdate" class="submit btn btn-default" >
											&nbsp;&nbsp;&nbsp;
										
							



								</div>
								</form>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>