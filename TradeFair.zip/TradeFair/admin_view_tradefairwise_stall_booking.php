<?php
session_start();
include("admin_header.php");
include("connection.php");


?>


	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>TRADE FAIR WISE STALL BOOKING DETAIL</center></h2>
			</div>
						
								<div class="col-md-12">
								<?php
								$tfid=$_REQUEST['tfid'];
								$qur1=mysql_query("select * from booking_detail where fair_id='$tfid'");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>BOOKING ID</th>
												<th>BOOKING DATE</th>
												<th>USER NAME</th>
												<th>USER MOBILE NO</th>
												<th>STALL ID</th>
												<th>STALL NO</th>
												<th>STALL SIZE</th>
												<th>STALL PRICE</th>
												
												
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											//echo "<td>$q1[2]</td>";
											$qur2=mysql_query("select * from user_registration where user_id='$q1[2]'");
											$q2=mysql_fetch_array($qur2);
											echo "<td>$q2[1]</td>";
											echo "<td>$q2[4]</td>";
											echo "<td>$q1[3]</td>";
											$qur3=mysql_query("select * from stall_detail where stall_id='$q1[3]'");
											$q3=mysql_fetch_array($qur3);
											echo "<td>$q3[2]</td>";
											echo "<td>$q3[3]</td>";
											echo "<td>$q3[4]</td>";
											//echo "<td>$q1[4]</td>";
											
											
											echo "</tr>";
										}
									echo "</table><br/><br/><br/><br/>";
								}else{
									echo "<h2>NO TRADE FAIR BOOKING FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>