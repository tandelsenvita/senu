<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">

    <title>Trade Fair</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="description">
    <meta content="http://webthemez.com" name="author">
	<!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
    <link href="css/jcarousel.css" rel="stylesheet">
    <link href="css/flexslider.css" rel="stylesheet">
    <link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<body>
    <div class="home-page" id="wrapper">
        <!-- start header -->

        <header>
            <div class="navbar navbar-default navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                        <button class="navbar-toggle" data-target=
                        ".navbar-collapse" data-toggle="collapse" type=
                        "button"><span class="icon-bar"></span> <span class=
                        "icon-bar"></span> <span class=
                        "icon-bar"></span></button> <a class="navbar-brand"
                        href="index.html"><img alt="logo" src=
                        "img/logo2.png"></a>
                    </div>

                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="active">
                                <a href="admin_manage_category.php">Manage Category</a>
                            </li>

                            <li>
                                <a href="admin_manage_trade_fair.php">Manage Trade Fair</a>
                            </li>

                            <li>
                                <a href="admin_view_current_trade_fair.php">View Bookings</a>
                            </li>

                           
							<li><a href="#" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Reports<span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a class="hvr-bounce-to-bottom" href="admin_view_user_detail_report.php">Registered User Detail Report</a></li>
									<li><a class="hvr-bounce-to-bottom" href="admin_view_cat_detail_report.php">Category Detail Report</a></li>
									<li><a class="hvr-bounce-to-bottom" href="admin_view_tradefair_report.php">Trade Fair Detail Report</a></li>
									<li><a class="hvr-bounce-to-bottom" href="admin_view_all_booking_report.php">All Booking Report</a></li>           
									<li><a class="hvr-bounce-to-bottom" href="admin_view_datewise_tradefair_report.php">Date Wise Trade Fair Detail Report</a></li>           
									<li><a class="hvr-bounce-to-bottom" href="admin_view_datewise_booking_report.php">Date Wise Booking Detail Report</a></li> 
											<li><a class="hvr-bounce-to-bottom" href="admin_view_todays_booking_report.php">Today's Booking Detail Report</a></li> 
								</ul>
							</li>	
                            

                            <li>
                                <a href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
			<hr/>
        </header><!-- end header -->
