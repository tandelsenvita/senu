<?php
include("header.php");
?>

<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Contact Us</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
					
					<div class="about">
					
						
						
						<div class="row">
        <div class="col-lg-6">
          <div class="about-carousel wow fadeInLeft animated" data-wow-animation-name="none">
            <div id="myCarousel" class="carousel slide">
              <!-- Carousel items -->
			   <img src="img/cnt1.jpg" alt="">
             
             
            </div>
          </div>
        </div>
        <div class="col-lg-6 about wow fadeInRight animated" data-wow-animation-name="none" style="visibility: visible; -webkit-animation-name: none;">
			<h2>CONTACT TRADE FAIR</h2>
			<H3>Address:</h3>
			<h4>
				1st Floor Internation Trade Center,<br/>
				Near Coastal Highway, <br/>
				Valsad - 396001,<br/>
				Gujarat (India)
			</h4>
			<H3>Mobile No:</h3>
			<h4>8547963210 | 6547891230 </h4>
            
			<H3>Email ID:</h3>
			<h4>admin@tradefair.com </h4>
          
        </div>
      </div>
						<br>
						
						
						 						
						 
						<br>
						
					  
						
					</div>
									
				</div>
	</section>
	
          



<?php
include("footer.php");
?>