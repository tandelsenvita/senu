<?php
session_start();
include("header.php");
include("connection.php");
?>
<script type="text/javascript">
function validation()
{
	var v=/^[a-zA-Z ]+$/
	if(form1.txtname.value=="")
	{
		alert("Please Enter Your Name");
		form1.txtname.focus();
		return false;
	}else{
		if(!v.test(form1.txtname.value))
		{
			alert("Please Enter Only Alphabets in Your Name");
			form1.txtname.focus();
			return false;
		}
	}
	
	if(form1.txtadd.value=="")
	{
		alert("Please Enter Your Address");
		form1.txtadd.focus();
		return false;
	}
	
	
	if(form1.txtcity.value=="")
	{
		alert("Please Enter Your City Name");
		form1.txtcity.focus();
		return false;
	}else{
		if(!v.test(form1.txtcity.value))
		{
			alert("Please Enter Only Alphabets in Your City Name");
			form1.txtcity.focus();
			return false;
		}
	}
	
	var v=/^[0-9]+$/
	if(form1.txtmno.value=="")
	{
		alert("Please Enter Your Mobile No");
		form1.txtmno.focus();
		return false;
	}else if(form1.txtmno.value.length!=10)
	{
		alert("Please Enter Only 10 Digits in Your Mobile No");
		form1.txtmno.focus();
		return false;
	}
	else{
		if(!v.test(form1.txtmno.value))
		{
			alert("Please Enter Only Digits in Your Mobile No");
			form1.txtmno.focus();
			return false;
		}
	}
	
	var v=/^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.([a-zA-Z]{2,4})+$/
	if(form1.txtemail.value=="")
	{
		alert("Please Enter Your Email ID");
		form1.txtemail.focus();
		return false;
	}else{
		if(!v.test(form1.txtemail.value))
		{
			alert("Please Enter Valid Email ID");
			form1.txtemail.focus();
			return false;
		}
	}
	
	if(form1.txtpwd.value=="")
	{
		alert("Please Enter Your Password");
		form1.txtpwd.focus();
		return false;
	}else if(form1.txtpwd.value.length<6)
	{
		alert("Please Enter Your Password More than 6 Characters");
		form1.txtpwd.focus();
		return false;
	}else if(form1.txtpwd.value.length>10)
	{
		alert("Please Enter Your Password Less than 10 Characters");
		form1.txtpwd.focus();
		return false;
	}
	
	
	if(form1.selque.value=="0")
	{
		alert("Please Select Security Question");
		form1.selque.focus();
		return false;
	}
	
	if(form1.txtsans.value=="")
	{
		alert("Please Enter Security Answer");
		form1.txtsans.focus();
		return false;
	}
	
	if(form1.gender[0].checked==false)
	{
		if(form1.gender[1].checked==false)
		{
			alert("Please Select Gender");
			return false;
		}
	}
}
</script>

<?php
if(isset($_POST['btnregis']))
{
	$name=$_POST['txtname'];
	$add=$_POST['txtadd'];
	$city=$_POST['txtcity'];
	$mno=$_POST['txtmno'];
	$email=$_POST['txtemail'];
	$pwd=$_POST['txtpwd'];
	$sque=$_POST['selque'];
	$sans=$_POST['txtsans'];
	$gender=$_POST['gender'];
	
	$res2=mysql_query("select * from user_registration where email_id='$email'");
	if(mysql_num_rows($res2)>0)
	{
		echo "<script type='text/javascript'>";
		echo "alert('Email Id Already Exists');";
		echo "window.location.href='register.php';";
		echo "</script>";
	}else{
		$qur=mysql_query("select max(user_id) from user_registration");
		$uid=0;
		while($q=mysql_fetch_array($qur))
		{
			$uid=$q[0];
		}
		$uid++;
		$query="insert into user_registration values('$uid','$name','$add','$city','$mno','$email','$pwd','$gender','$sque','$sans')";
		if(mysql_query($query))
		{
			echo "<script type='text/javascript'>";
			echo "alert('Registration Successfully ');";
			echo "window.location.href='login.php';";
			echo "</script>";
		}
	}
}
?>
<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">REGISTER</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post" name="form1" id="contactform" class="contact">
											<div class="form-group has-feedback">
												<label for="email">Enter Name*</label>
												<input type="text" class="form-control" name="txtname" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="message">Enter Address*</label>
												<textarea class="form-control" rows="3" name="txtadd" placeholder=""></textarea>
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter City*</label>
												<input type="text" class="form-control" name="txtcity" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Mobile No*</label>
												<input type="text" class="form-control" name="txtmno" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Email*</label>
												<input type="email" class="form-control" name="txtemail" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Enter Password*</label>
												<input type="password" class="form-control" name="txtpwd" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Select Security Question*</label>
												<select class="form-control" name="selque" >
													<option value="0">--Select Security Question--</option>
													<option value="What is Your Pet Name">What is Your Pet Name?</option>
													<option value="Your First Vehicle Name">Your First Vehicle Name?</option>
													<option value="Your Favourite Teacher Name">Your Favourite Teacher Name?</option>
													<option value="Your Favourite Food">Your Favourite Food?</option>
													<option value="Your Best Friend Name">Your Best Friend Name?</option>
												</select>
												
											</div>
											<div class="form-group has-feedback">
												<label for="email">Enter Security Answer*</label>
												<input type="text" class="form-control" name="txtsans" placeholder="">
												
											</div>
											<div class="form-group has-feedback">
												<label for="name">Select Gender</label> &nbsp;&nbsp;&nbsp;
												<input type="radio" name="gender" value="MALE">MALE &nbsp;&nbsp;&nbsp;
												<input type="radio" name="gender" value="FEMALE">FEMALE
											</div>
											
											<input type="submit" value="REGISTER" onclick="return validation();" name="btnregis" class="submit btn btn-default">
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-6">
									<br/><br/><br/>
 <img src="img/regis.png" style="width:700px; height:600px;"alt="">


								</div>
							</div>
							
	</div>
 
	</section>

<?php
include("footer.php");
?>