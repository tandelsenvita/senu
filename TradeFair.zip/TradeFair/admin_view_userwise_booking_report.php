<?php
session_start();
include("admin_header.php");
include("connection.php");


?>


	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>USER WISE STALL BOOKING DETAIL</center></h2>
			</div>
						
								<div class="col-md-12">
								<?php
								$userid=$_REQUEST['uid'];
								$qur1=mysql_query("select * from booking_detail where user_id='$userid'");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>BOOKING ID</th>
												<th>BOOKING DATE</th>
												<th>USER NAME</th>
												<th>USER MOBILE NO</th>
												<th>STALL ID</th>
												<th>STALL NO</th>
												<th>STALL SIZE</th>
												<th>STALL PRICE</th>
												<th>FAIR NAME</th>
												<th>DESCRIPTION</th>
												<th>ADDRESS</th>
												<th>MOBILE NO</th>
												<th>FAIR START DATE</th>
												<th>FAIR IMAGE</th>
												
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											//echo "<td>$q1[2]</td>";
											$qur2=mysql_query("select * from user_registration where user_id='$q1[2]'");
											$q2=mysql_fetch_array($qur2);
											echo "<td>$q2[1]</td>";
											echo "<td>$q2[4]</td>";
											echo "<td>$q1[3]</td>";
											$qur3=mysql_query("select * from stall_detail where stall_id='$q1[3]'");
											$q3=mysql_fetch_array($qur3);
											echo "<td>$q3[2]</td>";
											echo "<td>$q3[3]</td>";
											echo "<td>$q3[4]</td>";
											//echo "<td>$q1[4]</td>";
											$qur4=mysql_query("select * from trade_fair_master where fair_id='$q1[4]'");
											$q4=mysql_fetch_array($qur4);
											echo "<td>$q4[2]</td>";
											echo "<td>$q4[3]</td>";
											echo "<td>$q4[4]</td>";
											echo "<td>$q4[6]</td>";
											echo "<td>".date("d-m-Y",strtotime($q4[9]))."</td>";
											
											echo "<td><a href='$q4[11]' target='_blank'><img src='$q4[11]' style='width:250px; height:50px;'></a></td>";
											
											
											echo "</tr>";
										}
									echo "</table>";
								}else{
									echo "<h2>NO BOOKING FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>