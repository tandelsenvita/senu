<footer>
           

            <div id="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copyright">
                                <p><span>&copy; TradeFair 2021 All right reserved.
                                Designed By</span> <a href="#">Miss. Senvita Tandel | Miss. Dhruvi Tandel</a></p>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </div>
        </footer>
    </div><a class="scrollup fa fa-angle-up active" href="#"></a> <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script> 
	<script src="js/jquery.easing.1.3.js"></script> 
	<script src="js/bootstrap.min.js"></script> 
	<script src="js/jquery.fancybox.pack.js"></script> 
	<script src="js/jquery.fancybox-media.js"></script> 
	<script src="js/portfolio/jquery.quicksand.js"></script> 
	<script src="js/portfolio/setting.js"></script> 
	<script src="js/jquery.flexslider.js"></script> 
	<script src="js/animate.js"></script> 
	<script src="js/custom.js"></script> 
	<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>