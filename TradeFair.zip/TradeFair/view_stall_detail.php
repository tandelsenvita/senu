<?php
session_start();
include("header.php");
include("connection.php");

$tfid=$_REQUEST['tfid'];
$res1=mysql_query("select * from trade_fair_master where fair_id='$tfid'");
$r1=mysql_fetch_array($res1);
$catid=$r1[1];
$name=$r1[2];
$desc=$r1[3];
$add=$r1[4];
$city=$r1[5];
$mno=$r1[6];
$nstall=$r1[7];
$ndays=$r1[8];
$fsdate=$r1[9];
$bldate=$r1[10];
$fimg1=$r1[11];


if(isset($_REQUEST['stid']))
{
	$stid=$_REQUEST['stid'];
	if(isset($_SESSION['userid']))
	{
		$bdate=date("Y-m-d");
		$userid=$_SESSION['userid'];
		$qur=mysql_query("select max(booking_id) from booking_detail");
		$bid=0;
		while($q=mysql_fetch_array($qur))
		{
			$bid=$q[0];
		}
		$bid++;
		$query="insert into booking_detail values('$bid','$bdate','$userid','$stid','$tfid')";
		if(mysql_query($query))
		{
			echo "<script type='text/javascript'>";
			echo "alert('Stall Booked Successfully');";
			echo "window.location.href='user_payment.php?bid=$bid';";
			echo "</script>";
		}
	}else{
		$_SESSION['stid']=$stid;
		$_SESSION['tfid']=$tfid;
		header("Location: login.php");
	}
}
?>
<section id="inner-headline" class="bg-img">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">TRADE FAIR WISE STALL DETAIL</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
								<div class="col-md-6">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form">
											
		<form method="post"  id="contactform" class="contact">
											
											<div class="form-group has-feedback">
												<label for="email"><h4>Trade Fair Name: <?php echo $name; ?></h4></label>
												
												<label for="email"><h4>Description: <?php echo $desc; ?></h4></label>
												
												<label for="email"><h4>Address: <?php echo "$add $city"; ?></h4></label>
												
												<label for="email"><h4>Mobile No: <?php echo $mno; ?></h4></label>
												
												<label for="email"><h4>Booking Last Date: <?php echo $bldate; ?></h4></label>
												<br/>
												<label for="email"><h4>Trade Fair Start Date: <?php echo $fsdate; ?></h4></label>
												<br/>
												<label for="email"><h4>No of Days: <?php echo $ndays; ?></h4></label>
												<br/>
												<label for="email"><h4>No of Stall: <?php echo $nstall; ?></h4></label>
												
											</div>
											
										
										</form>
										 
										
									</div>
								</div>
								<div class="col-md-6">
								
 <img src="<?php echo $fimg1; ?>" alt="">


								</div>
							</div>
							<div class="row"> 
			<?php
			$qur=mysql_query("select * from stall_detail where fair_id='$tfid'");
			if(mysql_num_rows($qur)>0)
			{
				while($q=mysql_fetch_array($qur))
				{
			?>
							
			<div class="col-lg-3">
				<div class="pricing-box-item">
					<div class="pricing-heading">
						<h3><strong>Stall No: <?php echo $q[2]; ?></strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>Stall Charge: &#8377; <?php echo $q[4]; ?>/-</h6>
					</div>
					<div class="pricing-terms">
						<h6>Stall Size: <?php echo $q[3]; ?></h6>
					</div>
					<div class="pricing-action">
					<?php
					$qur7=mysql_query("select * from booking_detail where stall_id='$q[0]'");
					if(mysql_num_rows($qur7)>0)
					{
						?>
						<p style='color:red;' class="btn btn-medium"><i class="icon-bolt"></i> ALREADY BOOKED</p>
						<?php
						
					}else{
					?>
						<a href="view_stall_detail.php?stid=<?php echo $q[0]; ?>&tfid=<?php echo $tfid; ?>" class="btn btn-medium"><i class="icon-bolt"></i> BOOK NOW</a>
					<?php
					}
					?>
					</div>
				</div>
			</div>
		<?php
			}
		}else{
			echo "<h3>No Stall Detail Found</h3>";
		}
		?>	
		
			
		</div>
							
	</div>
 
	</section>

<?php
include("footer.php");
?>