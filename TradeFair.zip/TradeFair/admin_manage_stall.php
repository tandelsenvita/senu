<?php
include("admin_header.php");
include("connection.php");

$tfid=$_REQUEST['tfid'];
$nstall=$_REQUEST['nstall'];


if(isset($_POST['btnsave']))
{
	
	for($j=1;$j<=$nstall;$j++)
	{
		$sno=$_POST['txtstallno'.$j];
		$size=$_POST['txtsize'.$j];
		$charge=$_POST['txtcharge'.$j];
		//auto number code
		$qur=mysql_query("select max(stall_id) from stall_detail");
		$sid=0;
		while($q=mysql_fetch_array($qur))
		{
			$sid=$q[0];
		}
		$sid++;
		//auto number code end...
		$query="insert into stall_detail values('$sid','$tfid','$sno','$size','$charge')";
		mysql_query($query);
		
	}
	echo "<script type='text/javascript'>";
	echo "alert('Stall Detail Saved Successfully ');";
	echo "window.location.href='admin_manage_trade_fair.php';";
	echo "</script>";
	
}



if(isset($_REQUEST['dfid']))
{
	$fid=$_REQUEST['dfid'];
	$query="update trade_fair_master set status='1' where fair_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Not Visible Successfully');";
		echo "window.location.href='admin_manage_trade_fair.php';";
		echo "</script>";
	}
}

if(isset($_REQUEST['vfid']))
{
	$fid=$_REQUEST['vfid'];
	$query="update trade_fair_master set status='0' where fair_id='$fid'";
	if(mysql_query($query))
	{
		echo "<script type='text/javascript'>";
		echo "alert('Trade Fair Visible Successfully');";
		echo "window.location.href='admin_manage_trade_fair.php';";
		echo "</script>";
	}
}
?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>MANAGE STALL DETAIL</center></h2>
			</div>
			<form method="post"  id="contactform" name="form1" class="" enctype="multipart/form-data">
			<?php
			for($i=1;$i<=$nstall;$i++)
			{
			?>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											
											<div class="form-group has-feedback">
												<label for="email">Enter Stall No</label>
												<input type="text" class="form-control" name="txtstallno<?php echo $i; ?>" placeholder="" value="<?php echo $i; ?>" readonly>
												
											</div>
											
									</div>
								</div>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											<div class="form-group has-feedback">
												<label for="email">Enter Stall Size</label>
												<input type="text" class="form-control" name="txtsize<?php echo $i; ?>" placeholder="" required>
												
											</div>
											
											
											
											
											
									
										 
										
									</div>
								</div>
								<div class="col-md-4">
									<p></p>
									<div class="done">
			<div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert">×</button>
				Your message has been sent. Thank you!
			</div>
		</div>
									<div class="contact-form contact">
											
		
											<div class="form-group has-feedback">
												<label for="email">Enter Stall Charge</label>
												<input type="number" class="form-control" name="txtcharge<?php echo $i; ?>" placeholder="" required>
												
											</div>
											
											
											
											
											
										
										
										 
										
									</div>
								</div>
				<?php
				}
				?>
				
								<div class="col-md-12">
								
											<input type="submit" value="SAVE" name="btnsave" class="submit btn btn-default" >
											&nbsp;&nbsp;&nbsp;
										
							



								</div>
								</form>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>