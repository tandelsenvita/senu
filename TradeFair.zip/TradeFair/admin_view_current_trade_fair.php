<?php
session_start();
include("admin_header.php");
include("connection.php");


?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>VIEW UPCOMING TRADE FAIR</center></h2>
			</div>
								
								
								<div class="col-md-12">
								<?php
								$tdate=date("Y-m-d");
								$qur1=mysql_query("select * from trade_fair_master where fair_start_date>='$tdate'");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>FAIR ID</th>
												<th>CATEGORY</th>
												<th>FAIR NAME</th>
												<th>DESCRIPTION</th>
												<th>ADDRESS</th>
												<th>MOBILE NO</th>
												<th>NO OF STALL</th>
												<th>NO OF DAYS</th>
												<th>FAIR START DATE</th>
												<th>BOOKING LAST DATE</th>
												<th>FAIR IMAGE</th>
												<th>VIEW STALL BOOKING</th>
											
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											echo "<td>$q1[2]</td>";
											echo "<td>$q1[3]</td>";
											echo "<td>$q1[4] $q1[5]</td>";
											echo "<td>$q1[6]</td>";
											echo "<td>$q1[7]</td>";
											echo "<td>$q1[8]</td>";
											echo "<td>".date("d-m-Y",strtotime($q1[9]))."</td>";
											echo "<td>".date("d-m-Y",strtotime($q1[10]))."</td>";
											echo "<td><a href='$q1[11]' target='_blank'><img src='$q1[11]' style='width:250px; height:50px;'></a></td>";
											echo "<td><a href='admin_view_tradefairwise_stall_booking.php?tfid=$q1[0]'>VIEW STALL BOOKING</a></td>";
											
											
											
											echo "</tr>";
										}
									echo "</table>";
								}else{
									echo "<h2>NO TRADE FAIR CATEGORY FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>