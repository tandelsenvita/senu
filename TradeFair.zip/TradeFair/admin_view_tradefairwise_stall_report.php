<?php
include("admin_header.php");
include("connection.php");

?>

	<section id="content">
	
	<div class="container">
		
						
	<div class="row">
	<div class="col-lg-12">
				<h2 style="color: #FF4242; "><center>TRADE FAIR WISE STALL DETAIL REPORT</center></h2>
			</div>
							
								<div class="col-md-12">
								<?php
								$tfid=$_REQUEST['tfid'];
								$qur1=mysql_query("select * from stall_detail where fair_id='$tfid'");
								if(mysql_num_rows($qur1)>0)
								{
									echo "<table class='table table-bordered'>
											<tr>
												<th>STALL ID</th>
												<th>FAIR ID</th>
												<th>STALL NO</th>
												<th>STALL SIZE</th>
												<th>STALL CHARGE</th>
												
											</tr>";
										while($q1=mysql_fetch_array($qur1))
										{
											echo "<tr>";
											echo "<td>$q1[0]</td>";
											echo "<td>$q1[1]</td>";
											echo "<td>$q1[2]</td>";
											echo "<td>$q1[3]</td>";
											echo "<td>$q1[4]</td>";
											
											echo "</tr>";
										}
									echo "</table>";
								}else{
									echo "<h2>NO STALL FOUND</h2>";
								}
								?>



								</div>
							</div>
							
	</div>
 
	</section>
<?php
include("footer.php");
?>