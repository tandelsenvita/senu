-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 27, 2021 at 06:05 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `trade_fair`
--
CREATE DATABASE IF NOT EXISTS `trade_fair` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `trade_fair`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `email_id` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`email_id`, `password`) VALUES
('admin@tradefair.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking_detail`
--

CREATE TABLE IF NOT EXISTS `booking_detail` (
  `booking_id` int(10) NOT NULL,
  `booking_date` date NOT NULL,
  `user_id` int(10) NOT NULL,
  `stall_id` int(10) NOT NULL,
  `fair_id` int(10) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking_detail`
--

INSERT INTO `booking_detail` (`booking_id`, `booking_date`, `user_id`, `stall_id`, `fair_id`) VALUES
(1, '2021-05-06', 1, 1, 1),
(2, '2021-05-25', 1, 7, 2),
(3, '2021-05-26', 2, 9, 2),
(4, '2021-05-27', 2, 8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` int(10) NOT NULL,
  `booking_id` int(10) NOT NULL,
  `card_type` varchar(15) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `card_holder_name` varchar(50) NOT NULL,
  `card_no` varchar(16) NOT NULL,
  `cvv_no` int(5) NOT NULL,
  `expiry_date` varchar(10) NOT NULL,
  `amount` int(10) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `booking_id`, `card_type`, `bank_name`, `card_holder_name`, `card_no`, `cvv_no`, `expiry_date`, `amount`) VALUES
(1, 1, 'Debit Card', 'bob', 'senviat tandel', '1234567890123456', 111, 'June-2024', 8000),
(2, 2, 'Debit Card', 'bob', 'senviat tandel', '7412589630123456', 111, 'April-2023', 50000),
(3, 3, 'Credit Card', 'sbi', 'dhruvi', '1478523690123456', 111, 'April-2024', 75000),
(4, 4, 'Debit Card', 'sbi', 'dhruvi', '1234567890123456', 111, 'April-2024', 75000);

-- --------------------------------------------------------

--
-- Table structure for table `stall_detail`
--

CREATE TABLE IF NOT EXISTS `stall_detail` (
  `stall_id` int(10) NOT NULL,
  `fair_id` int(10) NOT NULL,
  `stall_no` int(10) NOT NULL,
  `stall_size` varchar(20) NOT NULL,
  `stall_charge` int(10) NOT NULL,
  PRIMARY KEY (`stall_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stall_detail`
--

INSERT INTO `stall_detail` (`stall_id`, `fair_id`, `stall_no`, `stall_size`, `stall_charge`) VALUES
(1, 1, 1, '300 x 400', 8000),
(2, 1, 2, '400 x 500', 10000),
(3, 1, 3, '600 x 700', 15000),
(4, 1, 4, '600 x 700', 15000),
(5, 1, 5, '1000 x 1200', 20000),
(6, 2, 1, '2000 x 2000', 50000),
(7, 2, 2, '2000 x 2000', 50000),
(8, 2, 3, '3000 x 3000', 75000),
(9, 2, 4, '3000 x 3000', 75000),
(10, 2, 5, '4000 x 4000', 90000);

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_category`
--

CREATE TABLE IF NOT EXISTS `trade_fair_category` (
  `category_id` int(10) NOT NULL,
  `category` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_category`
--

INSERT INTO `trade_fair_category` (`category_id`, `category`, `status`) VALUES
(1, 'Machinery', 0),
(2, 'Auto ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_master`
--

CREATE TABLE IF NOT EXISTS `trade_fair_master` (
  `fair_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `trade_fair_name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `no_of_stall` int(5) NOT NULL,
  `no_of_days` int(5) NOT NULL,
  `fair_start_date` date NOT NULL,
  `book_last_date` date NOT NULL,
  `fair_img` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`fair_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_master`
--

INSERT INTO `trade_fair_master` (`fair_id`, `category_id`, `trade_fair_name`, `description`, `address`, `city`, `mobile_no`, `no_of_stall`, `no_of_days`, `fair_start_date`, `book_last_date`, `fair_img`, `status`) VALUES
(1, 1, 'Machinery Trade Fair 2021', 'Machinery Trade Fair 2021 is machinery trade fair all type of industrial machinery fair for your essential need of business', 'monghbhai hall', 'valsad', '9874563210', 5, 2, '2021-06-30', '2021-06-29', 'fair_image/F1_3034.png', 0),
(2, 2, 'Auto Expo 2021', 'Fastest Sports Car Expo from all over the world', 'cb school ground halar', 'valsad', '9685741230', 5, 2, '2021-05-31', '2021-05-30', 'fair_image/F2_6555.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE IF NOT EXISTS `user_registration` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `security_que` varchar(200) NOT NULL,
  `security_ans` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`user_id`, `user_name`, `address`, `city`, `mobile_no`, `email_id`, `password`, `gender`, `security_que`, `security_ans`) VALUES
(1, 'Senvita Tandel', 'dati', 'valsad', '8574123690', 'senvita@yahoo.com', '111111', 'FEMALE', 'What is Your Pet Name', 'senu'),
(2, 'dhruvi', 'dati', 'valsad', '8574123690', 'dhruvi@yahoo.com', '111111', 'FEMALE', 'Your First Vehicle Name', 'activa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
